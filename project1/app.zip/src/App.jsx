import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'

function App() {
  const [count, setCount] = useState(0)

  return (
    <>
      <h1 className='bg-green-600 p-40 text-500 rounded-lg '>
        Hey i'm chandan it mins react devloper
      </h1>
    </>
  )
}

export default App
